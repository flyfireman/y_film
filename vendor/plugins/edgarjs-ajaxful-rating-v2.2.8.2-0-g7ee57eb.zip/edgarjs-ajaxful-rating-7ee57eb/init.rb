puts "------------------------------------------"
puts "IMPORTANT: AjaxfulRating has been updated to v2.2.x and some options changed."\
  "Please read the changelog at http://github.com/edgarjs/ajaxful-rating/blob/master/CHANGELOG"
puts "------------------------------------------"

require 'ajaxful_rating'
